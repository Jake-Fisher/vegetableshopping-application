export class User {
    id: number;
    name: string;
    type: string;  
    password: string;
  }