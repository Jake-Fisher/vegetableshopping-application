export class Vege {
    id: number;
    name: string;
    seller: string;
    price: number;
    picByte: string;
    retrievedImage: string;
    isAdded: boolean;
    }